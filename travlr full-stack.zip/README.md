# CS465-fullstack
Full Stack Development of Web Application with MEAN
Developed by Charles Campbell
Last updated: 15 August 2025

# Project Setup

1. Run `npm install` to install dependencies.
2. Run `npm start` to launch the app.